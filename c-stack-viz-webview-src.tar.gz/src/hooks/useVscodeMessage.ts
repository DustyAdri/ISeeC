import { useEffect } from "react";
import { StepData } from "../types/stepTypes";

interface Handlers {
  onStep: (step: StepData) => void;
  onError: (message: string) => void;
  onFinished: (finalStep: StepData | null) => void;
  onReset: () => void;
}

/**
 * Attaches a `window.addEventListener("message", ...)` on mount and
 * dispatches to the correct handler based on `event.data.type`.
 * Cleans up the listener on unmount.
 */
export function useVscodeMessage(handlers: Handlers): void {
  useEffect(() => {
    function listener(event: MessageEvent) {
      const msg = event.data;
      if (!msg || typeof msg.type !== "string") {
        return;
      }

      switch (msg.type) {
        case "step":
          handlers.onStep(msg.payload as StepData);
          break;
        case "error":
          handlers.onError(msg.message as string);
          break;
        case "finished":
          handlers.onFinished((msg.payload as StepData) ?? null);
          break;
        case "reset":
          handlers.onReset();
          break;
        // Unknown message types are silently ignored per the SRS.
      }
    }

    window.addEventListener("message", listener);
    return () => window.removeEventListener("message", listener);
    // handlers intentionally omitted from deps — they are inline lambdas in
    // App.tsx and would cause infinite re-attachment if included.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}
