import React from "react";

/**
 * Fixed landmark node at the bottom of the Heap panel.
 * Not interactive. Null pointers do NOT draw arrows to this node —
 * it is a visual reference only (per SRS Section 5.6).
 */
export const NullSentinel: React.FC = () => {
  return (
    <div id="heap-null" className="null-sentinel" aria-label="NULL sentinel">
      NULL
    </div>
  );
};
