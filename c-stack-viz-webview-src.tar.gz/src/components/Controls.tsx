import React from "react";
import { vscodeApi } from "../vscodeApi";

interface ControlsProps {
  step: number;
  totalSteps: number;
  finished: boolean;
}

export const Controls: React.FC<ControlsProps> = ({
  step,
  totalSteps,
  finished,
}) => {
  const handleBack = () => {
    vscodeApi.postMessage({ type: "requestStep", direction: "backward" });
  };

  const handleForward = () => {
    vscodeApi.postMessage({ type: "requestStep", direction: "forward" });
  };

  const handleReset = () => {
    vscodeApi.postMessage({ type: "requestReset" });
  };

  const isFirst = step <= 1;
  const isFinished = finished;

  return (
    <div className="controls">
      <button
        className="ctrl-btn ctrl-btn--back"
        onClick={handleBack}
        disabled={isFirst}
        title="Previous step"
        aria-label="Step back"
      >
        ◀ Back
      </button>

      <span className="ctrl-counter">
        {totalSteps === 0 ? (
          <span className="ctrl-counter__idle">Waiting for trace…</span>
        ) : (
          <>
            Step <strong>{step}</strong>
            <span className="ctrl-counter__sep">/</span>
            <strong>{totalSteps}</strong>
            {finished && (
              <span className="ctrl-counter__done"> · Done</span>
            )}
          </>
        )}
      </span>

      <button
        className="ctrl-btn ctrl-btn--forward"
        onClick={handleForward}
        disabled={isFinished}
        title="Next step"
        aria-label="Step forward"
      >
        Forward ▶
      </button>

      <button
        className="ctrl-btn ctrl-btn--reset"
        onClick={handleReset}
        title="Reset trace"
        aria-label="Reset"
      >
        Reset
      </button>
    </div>
  );
};
