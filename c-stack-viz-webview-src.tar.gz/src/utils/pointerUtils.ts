/** Returns true if the C type string represents a pointer (ends with "*"). */
export function isPointerType(type: string): boolean {
  return type.trimEnd().endsWith("*");
}

/**
 * Shorten a hex address for display.
 * e.g. "0x8040200" → "0x8040…"
 */
export function shortenAddress(addr: string): string {
  if (addr.length <= 6) {
    return addr;
  }
  return addr.slice(0, 6) + "…";
}

/** Returns true if the address is the null pointer sentinel. */
export function isNullAddress(addr: string): boolean {
  return addr === "0x0";
}
