/**
 * Acquire the VS Code webview API exactly once.
 * Falls back to a no-op stub when running outside of VS Code
 * (e.g., in a browser for development/testing).
 */

interface VscodeApi {
  postMessage(message: unknown): void;
  getState(): unknown;
  setState(state: unknown): void;
}

declare function acquireVsCodeApi(): VscodeApi;

function createStub(): VscodeApi {
  return {
    postMessage(message: unknown) {
      console.log("[vscode stub] postMessage:", message);
    },
    getState() {
      return undefined;
    },
    setState(_state: unknown) {
      /* no-op */
    },
  };
}

export const vscodeApi: VscodeApi =
  typeof acquireVsCodeApi === "function"
    ? acquireVsCodeApi()
    : createStub();
